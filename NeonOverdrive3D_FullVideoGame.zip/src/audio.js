export const AudioEngine = (() => {
  let ctx = null;
  let master = null;
  let noiseBuf = null;
  let muted = false;
  let musicTimer = null;
  let step = 0;
  let mode = 'MENU'; // MENU, PLAY, NITRO, BOSS

  const BASS_PLAY = [55, 55, 55, 55, 65.41, 65.41, 73.42, 73.42, 49, 49, 49, 49, 61.74, 61.74, 55, 49];
  const ARP_PLAY  = [220, 261.63, 329.63, 440, 261.63, 329.63, 392, 523.25, 196, 246.94, 293.66, 392, 220, 329.63, 440, 523.25];
  const BASS_BOSS = [46.25, 46.25, 55, 46.25, 49, 49, 61.74, 49, 46.25, 55, 65.41, 46.25, 73.42, 65.41, 55, 49];

  function ensure() {
    if (!ctx) {
      const AC = window.AudioContext || window.webkitAudioContext;
      if (!AC) return false;
      ctx = new AC();
      master = ctx.createGain();
      master.gain.value = muted ? 0 : 0.72;
      master.connect(ctx.destination);

      // Explosion / hi-hat noise buffer
      const sr = ctx.sampleRate;
      noiseBuf = ctx.createBuffer(1, Math.floor(sr * 0.5), sr);
      const ch = noiseBuf.getChannelData(0);
      for (let i = 0; i < ch.length; i++) {
        ch[i] = (Math.random() * 2 - 1) * Math.exp(-i / (sr * 0.14));
      }
    }
    if (ctx.state === 'suspended') ctx.resume();
    return true;
  }

  function setMuted(m) {
    muted = !!m;
    if (master && ctx) master.gain.setTargetAtTime(muted ? 0 : 0.72, ctx.currentTime, 0.03);
  }

  function setMode(newMode) {
    mode = newMode;
  }

  function startMusic() {
    if (!ensure() || musicTimer) return;
    musicTimer = setInterval(() => {
      if (muted || !ctx || ctx.state !== 'running') return;
      if (mode === 'MENU') return;
      const now = ctx.currentTime;
      const idx = step % 16;

      // 1. Punchy 4-on-the-floor Synthwave Kick
      if (idx % 4 === 0 || (mode === 'BOSS' && idx === 14)) {
        const osc = ctx.createOscillator();
        const g = ctx.createGain();
        osc.type = 'sine';
        osc.frequency.setValueAtTime(mode === 'NITRO' ? 150 : 128, now);
        osc.frequency.exponentialRampToValueAtTime(34, now + 0.12);
        g.gain.setValueAtTime(0.32, now);
        g.gain.exponentialRampToValueAtTime(0.001, now + 0.13);
        osc.connect(g); g.connect(master);
        osc.start(now); osc.stop(now + 0.14);
      }

      // 2. Crisp Hi-Hat on offbeats
      if (idx % 2 === 1 && noiseBuf) {
        const src = ctx.createBufferSource();
        src.buffer = noiseBuf;
        const hp = ctx.createBiquadFilter();
        hp.type = 'highpass';
        hp.frequency.value = 7200;
        const g = ctx.createGain();
        g.gain.setValueAtTime(mode === 'NITRO' ? 0.09 : 0.055, now);
        g.gain.exponentialRampToValueAtTime(0.001, now + 0.045);
        src.connect(hp); hp.connect(g); g.connect(master);
        src.start(now);
      }

      // 3. Driving Sawtooth Synthwave Bass
      const bassFreq = mode === 'BOSS' ? BASS_BOSS[idx] : BASS_PLAY[idx];
      const bOsc = ctx.createOscillator();
      const bFilt = ctx.createBiquadFilter();
      const bGain = ctx.createGain();
      bOsc.type = 'sawtooth';
      bOsc.frequency.setValueAtTime(bassFreq * (mode === 'NITRO' ? 1.12 : 1.0), now);
      bFilt.type = 'lowpass';
      bFilt.frequency.setValueAtTime(mode === 'NITRO' ? 920 : 520, now);
      bGain.gain.setValueAtTime(0.14, now);
      bGain.gain.exponentialRampToValueAtTime(0.001, now + 0.11);
      bOsc.connect(bFilt); bFilt.connect(bGain); bGain.connect(master);
      bOsc.start(now); bOsc.stop(now + 0.12);

      // 4. Shimmering Cyber Arpeggio
      if (mode !== 'BOSS' || idx % 2 === 0) {
        const arpFreq = ARP_PLAY[idx] * (mode === 'NITRO' ? 1.5 : 1.0);
        const aOsc = ctx.createOscillator();
        const aGain = ctx.createGain();
        aOsc.type = 'triangle';
        aOsc.frequency.setValueAtTime(arpFreq, now);
        aGain.gain.setValueAtTime(0.065, now);
        aGain.gain.exponentialRampToValueAtTime(0.001, now + 0.1);
        aOsc.connect(aGain); aGain.connect(master);
        aOsc.start(now); aOsc.stop(now + 0.11);
      }

      step++;
    }, 115); // ~130 BPM 16th-note pulse
  }

  function playLaser(heavy = false) {
    if (muted || !ensure()) return;
    const now = ctx.currentTime;
    const osc = ctx.createOscillator();
    const g = ctx.createGain();
    osc.type = heavy ? 'sawtooth' : 'triangle';
    osc.frequency.setValueAtTime(heavy ? 760 : 1080, now);
    osc.frequency.exponentialRampToValueAtTime(heavy ? 180 : 280, now + 0.065);
    g.gain.setValueAtTime(0.11, now);
    g.gain.exponentialRampToValueAtTime(0.001, now + 0.07);
    osc.connect(g); g.connect(master);
    osc.start(now); osc.stop(now + 0.075);
  }

  function playCoin(combo = 1) {
    if (muted || !ensure()) return;
    const now = ctx.currentTime;
    const f = 880 * Math.pow(1.05, Math.min(combo, 16));
    const osc = ctx.createOscillator();
    const g = ctx.createGain();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(f, now);
    osc.frequency.setValueAtTime(f * 1.33, now + 0.045);
    g.gain.setValueAtTime(0.16, now);
    g.gain.exponentialRampToValueAtTime(0.001, now + 0.14);
    osc.connect(g); g.connect(master);
    osc.start(now); osc.stop(now + 0.15);
  }

  function playNearMiss(combo = 1) {
    if (muted || !ensure()) return;
    const now = ctx.currentTime;
    const f = 440 * Math.pow(1.07, Math.min(combo, 18));
    // Futuristic electric whoosh + rising ping
    const osc = ctx.createOscillator();
    const g = ctx.createGain();
    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(f * 0.7, now);
    osc.frequency.exponentialRampToValueAtTime(f * 1.9, now + 0.12);
    g.gain.setValueAtTime(0.18, now);
    g.gain.exponentialRampToValueAtTime(0.001, now + 0.16);
    osc.connect(g); g.connect(master);
    osc.start(now); osc.stop(now + 0.17);
  }

  function playExplosion(big = false) {
    if (muted || !ensure()) return;
    const now = ctx.currentTime;
    // Sub boom
    const sub = ctx.createOscillator();
    const sg = ctx.createGain();
    sub.type = 'sine';
    sub.frequency.setValueAtTime(big ? 140 : 105, now);
    sub.frequency.exponentialRampToValueAtTime(24, now + (big ? 0.48 : 0.24));
    sg.gain.setValueAtTime(big ? 0.55 : 0.34, now);
    sg.gain.exponentialRampToValueAtTime(0.001, now + (big ? 0.52 : 0.26));
    sub.connect(sg); sg.connect(master);
    sub.start(now); sub.stop(now + (big ? 0.55 : 0.28));

    // Debris crackle
    if (noiseBuf) {
      const src = ctx.createBufferSource();
      src.buffer = noiseBuf;
      const lp = ctx.createBiquadFilter();
      lp.type = 'lowpass';
      lp.frequency.setValueAtTime(big ? 1600 : 2400, now);
      lp.frequency.exponentialRampToValueAtTime(180, now + (big ? 0.45 : 0.22));
      const ng = ctx.createGain();
      ng.gain.setValueAtTime(big ? 0.45 : 0.26, now);
      ng.gain.exponentialRampToValueAtTime(0.001, now + (big ? 0.48 : 0.24));
      src.connect(lp); lp.connect(ng); ng.connect(master);
      src.start(now);
    }
  }

  function playNitro() {
    if (muted || !ensure()) return;
    const now = ctx.currentTime;
    const osc = ctx.createOscillator();
    const g = ctx.createGain();
    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(160, now);
    osc.frequency.exponentialRampToValueAtTime(980, now + 0.35);
    g.gain.setValueAtTime(0.24, now);
    g.gain.exponentialRampToValueAtTime(0.001, now + 0.42);
    osc.connect(g); g.connect(master);
    osc.start(now); osc.stop(now + 0.45);
  }

  function playBossAlarm() {
    if (muted || !ensure()) return;
    const now = ctx.currentTime;
    for (let i = 0; i < 3; i++) {
      const t = now + i * 0.28;
      const osc = ctx.createOscillator();
      const g = ctx.createGain();
      osc.type = 'square';
      osc.frequency.setValueAtTime(520, t);
      osc.frequency.linearRampToValueAtTime(340, t + 0.22);
      g.gain.setValueAtTime(0.16, t);
      g.gain.exponentialRampToValueAtTime(0.001, t + 0.24);
      osc.connect(g); g.connect(master);
      osc.start(t); osc.stop(t + 0.25);
    }
  }

  function playPowerup() {
    if (muted || !ensure()) return;
    const now = ctx.currentTime;
    [523.25, 659.25, 783.99, 1046.5].forEach((f, i) => {
      const osc = ctx.createOscillator();
      const g = ctx.createGain();
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(f, now + i * 0.055);
      g.gain.setValueAtTime(0.18, now + i * 0.055);
      g.gain.exponentialRampToValueAtTime(0.001, now + i * 0.055 + 0.16);
      osc.connect(g); g.connect(master);
      osc.start(now + i * 0.055); osc.stop(now + i * 0.055 + 0.18);
    });
  }

  function playClick() {
    if (muted || !ensure()) return;
    const now = ctx.currentTime;
    const osc = ctx.createOscillator();
    const g = ctx.createGain();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(640, now);
    osc.frequency.exponentialRampToValueAtTime(920, now + 0.04);
    g.gain.setValueAtTime(0.12, now);
    g.gain.exponentialRampToValueAtTime(0.001, now + 0.05);
    osc.connect(g); g.connect(master);
    osc.start(now); osc.stop(now + 0.055);
  }

  return {
    ensure, setMuted, setMode, startMusic,
    playLaser, playCoin, playNearMiss, playExplosion, playNitro, playBossAlarm, playPowerup, playClick
  };
})();
