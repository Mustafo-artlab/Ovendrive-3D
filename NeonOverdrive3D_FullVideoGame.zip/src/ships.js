import * as THREE from 'three';

export function buildPlayerShip(shipSpec, textures) {
  const group = new THREE.Group();

  const hullMat = new THREE.MeshStandardMaterial({
    color: shipSpec.hullColor,
    map: textures.hullDiffuse,
    bumpMap: textures.hullBump,
    bumpScale: 0.05,
    metalness: 0.86,
    roughness: 0.24
  });

  const trimMat = new THREE.MeshStandardMaterial({
    color: shipSpec.primaryColor,
    emissive: shipSpec.primaryColor,
    emissiveIntensity: 2.2,
    metalness: 0.4,
    roughness: 0.2
  });

  const accentMat = new THREE.MeshStandardMaterial({
    color: shipSpec.accentColor,
    emissive: shipSpec.accentColor,
    emissiveIntensity: 2.0,
    metalness: 0.3,
    roughness: 0.2
  });

  const canopyMat = new THREE.MeshPhysicalMaterial({
    color: 0x08162a,
    emissive: shipSpec.primaryColor,
    emissiveIntensity: 0.35,
    metalness: 0.2,
    roughness: 0.06,
    clearcoat: 1.0,
    clearcoatRoughness: 0.05
  });

  // 1. Sleek Main Fuselage Nose Cone
  const noseGeo = new THREE.ConeGeometry(0.42, 2.8, 6);
  noseGeo.rotateX(-Math.PI / 2);
  noseGeo.scale(1.15, 0.52, 1.0);
  const nose = new THREE.Mesh(noseGeo, hullMat);
  nose.position.set(0, 0, -0.4);
  group.add(nose);

  // Rear Core Chassis
  const core = new THREE.Mesh(new THREE.BoxGeometry(0.85, 0.36, 1.35), hullMat);
  core.position.set(0, 0, 0.72);
  group.add(core);

  // Glossy Cockpit Canopy
  const canopyGeo = new THREE.SphereGeometry(0.32, 16, 12);
  canopyGeo.scale(0.95, 0.55, 2.1);
  const canopy = new THREE.Mesh(canopyGeo, canopyMat);
  canopy.position.set(0, 0.22, -0.15);
  group.add(canopy);

  // 2. Ship-specific Wings & Geometry
  const wingSpread = shipSpec.id === 'titan' ? 1.85 : (shipSpec.id === 'solaris' ? 2.05 : 1.65);
  const wingGeo = new THREE.BoxGeometry(wingSpread * 2, 0.09, 1.05);
  const mainWing = new THREE.Mesh(wingGeo, hullMat);
  mainWing.position.set(0, -0.04, 0.55);
  group.add(mainWing);

  // Swept wing blades (left & right)
  for (const side of [-1, 1]) {
    const blade = new THREE.Mesh(new THREE.BoxGeometry(0.95, 0.07, 1.55), hullMat);
    blade.position.set(side * (wingSpread * 0.72), -0.02, 0.25);
    blade.rotation.y = side * -0.45;
    group.add(blade);

    // Neon Plasma Wing Strips
    const strip = new THREE.Mesh(new THREE.BoxGeometry(0.1, 0.06, 1.65), side === -1 ? trimMat : accentMat);
    strip.position.set(side * (wingSpread * 0.96), 0.02, 0.42);
    strip.rotation.y = side * -0.18;
    group.add(strip);

    // Angled Vertical Stabilizer Fins
    const fin = new THREE.Mesh(new THREE.BoxGeometry(0.08, 0.52, 0.82), hullMat);
    fin.position.set(side * 0.72, 0.26, 0.85);
    fin.rotation.z = side * -0.35;
    group.add(fin);

    // Forward Laser Cannon Barrels
    const barrel = new THREE.Mesh(new THREE.CylinderGeometry(0.045, 0.06, 1.1, 8), trimMat);
    barrel.rotation.x = Math.PI / 2;
    barrel.position.set(side * 0.88, -0.08, -0.35);
    group.add(barrel);
  }

  // Extra Solar Halo / Forward Canards for Solaris & Phantom
  if (shipSpec.id === 'solaris') {
    const halo = new THREE.Mesh(new THREE.TorusGeometry(0.95, 0.045, 10, 28), trimMat);
    halo.position.set(0, 0.05, 0.75);
    group.add(halo);
  } else if (shipSpec.id === 'phantom') {
    for (const side of [-1, 1]) {
      const canard = new THREE.Mesh(new THREE.BoxGeometry(0.65, 0.05, 0.45), accentMat);
      canard.position.set(side * 0.65, 0.02, -0.85);
      canard.rotation.y = side * 0.4;
      group.add(canard);
    }
  } else if (shipSpec.id === 'titan') {
    const topGun = new THREE.Mesh(new THREE.CylinderGeometry(0.06, 0.08, 1.35, 8), accentMat);
    topGun.rotation.x = Math.PI / 2;
    topGun.position.set(0, 0.36, -0.45);
    group.add(topGun);
  }

  // 3. Twin / Quad Glowing Thruster Cones
  const thrusters = [];
  const thrusterPositions = shipSpec.cannons >= 3 ? [-0.46, 0, 0.46] : [-0.34, 0.34];
  const flameMat = new THREE.MeshBasicMaterial({
    color: shipSpec.primaryColor,
    transparent: true,
    opacity: 0.92
  });
  for (const tx of thrusterPositions) {
    const nozzle = new THREE.Mesh(new THREE.CylinderGeometry(0.16, 0.2, 0.35, 12), hullMat);
    nozzle.rotation.x = Math.PI / 2;
    nozzle.position.set(tx, -0.02, 1.42);
    group.add(nozzle);

    const flameGeo = new THREE.ConeGeometry(0.16, 1.35, 10);
    flameGeo.rotateX(Math.PI / 2);
    const flame = new THREE.Mesh(flameGeo, flameMat);
    flame.position.set(tx, -0.02, 2.15);
    group.add(flame);
    thrusters.push(flame);
  }

  // 4. Energy Shield Dome (hidden until active)
  const shieldMesh = new THREE.Mesh(
    new THREE.IcosahedronGeometry(2.05, 2),
    new THREE.MeshBasicMaterial({
      color: 0x00ffaa,
      wireframe: true,
      transparent: true,
      opacity: 0.42
    })
  );
  shieldMesh.visible = false;
  group.add(shieldMesh);

  // Dynamic Engine PointLight (lights up the metallic highway underneath!)
  const engineLight = new THREE.PointLight(shipSpec.primaryColor, 5.5, 16);
  engineLight.position.set(0, 0.4, 1.8);
  group.add(engineLight);

  group.userData = { thrusters, shieldMesh, engineLight, flameMat };
  return group;
}

export function buildEnemyDrone(textures) {
  const group = new THREE.Group();
  const bodyMat = new THREE.MeshStandardMaterial({
    color: 0x22162e,
    map: textures.hullDiffuse,
    metalness: 0.85,
    roughness: 0.25
  });
  const coreMat = new THREE.MeshStandardMaterial({
    color: 0xff1e4d,
    emissive: 0xff1e4d,
    emissiveIntensity: 2.8
  });

  const core = new THREE.Mesh(new THREE.OctahedronGeometry(0.85, 0), bodyMat);
  group.add(core);

  const ring = new THREE.Mesh(new THREE.TorusGeometry(1.15, 0.11, 8, 20), coreMat);
  ring.rotation.x = Math.PI / 2;
  group.add(ring);

  const eye = new THREE.Mesh(new THREE.SphereGeometry(0.42, 12, 12), coreMat);
  eye.position.z = 0.62;
  group.add(eye);

  group.userData = { ring, core };
  return group;
}

export function buildBossDreadnought(textures, biomeIdx = 0) {
  const group = new THREE.Group();
  const colors = [0xff1144, 0xffaa00, 0xcc00ff];
  const glowCol = colors[biomeIdx % colors.length];

  const armorMat = new THREE.MeshStandardMaterial({
    color: 0x161426,
    map: textures.hullDiffuse,
    bumpMap: textures.hullBump,
    bumpScale: 0.08,
    metalness: 0.9,
    roughness: 0.2
  });

  const glowMat = new THREE.MeshStandardMaterial({
    color: glowCol,
    emissive: glowCol,
    emissiveIntensity: 3.0,
    metalness: 0.2,
    roughness: 0.1
  });

  // Colossal Armored Core Hull
  const mainBody = new THREE.Mesh(new THREE.BoxGeometry(8.5, 2.4, 4.2), armorMat);
  group.add(mainBody);

  // Upper Citadel Bridge
  const bridge = new THREE.Mesh(new THREE.BoxGeometry(3.8, 1.6, 2.6), armorMat);
  bridge.position.set(0, 1.8, -0.2);
  group.add(bridge);

  // Rotating Reactor Ring
  const reactorRing = new THREE.Mesh(new THREE.TorusGeometry(2.65, 0.24, 12, 32), glowMat);
  reactorRing.position.set(0, 0, 1.9);
  group.add(reactorRing);

  // Glowing Central Heart Core
  const heart = new THREE.Mesh(new THREE.IcosahedronGeometry(1.35, 1), glowMat);
  heart.position.set(0, 0, 2.1);
  group.add(heart);

  // Twin Massive Cannon Pods
  const cannons = [];
  for (const side of [-1, 1]) {
    const pod = new THREE.Mesh(new THREE.BoxGeometry(2.2, 1.8, 5.2), armorMat);
    pod.position.set(side * 5.2, -0.2, 0.6);
    group.add(pod);

    const tip = new THREE.Mesh(new THREE.CylinderGeometry(0.45, 0.55, 1.4, 12), glowMat);
    tip.rotation.x = Math.PI / 2;
    tip.position.set(side * 5.2, -0.2, 3.4);
    group.add(tip);
    cannons.push(tip);
  }

  const bossLight = new THREE.PointLight(glowCol, 12, 36);
  bossLight.position.set(0, -1, 4.5);
  group.add(bossLight);

  group.userData = { reactorRing, heart, cannons, glowMat, armorMat };
  return group;
}
