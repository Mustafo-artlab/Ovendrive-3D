export const SHIPS = [
  {
    id: 'viper',
    name: 'VIPER MK-I',
    role: 'Balanced Interceptor',
    price: 0,
    primaryColor: 0x00f0ff,
    accentColor: 0xff00cc,
    hullColor: 0x1a2442,
    speedBonus: 1.0,
    fireRateBonus: 1.0,
    handling: 1.0,
    cannons: 2,
    desc: 'Agile dual-plasma interceptor built for high-speed canyon runs.'
  },
  {
    id: 'phantom',
    name: 'PHANTOM X',
    role: 'Stealth Hyper-Wing',
    price: 600,
    primaryColor: 0xb537ff,
    accentColor: 0x00ffcc,
    hullColor: 0x18152c,
    speedBonus: 1.12,
    fireRateBonus: 1.15,
    handling: 1.22,
    cannons: 2,
    desc: 'Razor-sharp handling with ultra-fast plasma fire rate.'
  },
  {
    id: 'titan',
    name: 'TITAN VANGUARD',
    role: 'Heavy Triple-Cannon',
    price: 1500,
    primaryColor: 0xff5500,
    accentColor: 0xffdd00,
    hullColor: 0x261a1d,
    speedBonus: 1.05,
    fireRateBonus: 1.2,
    handling: 0.96,
    cannons: 3,
    desc: 'Triple plasma volley shreds Cyber-Drones and Boss cores fast.'
  },
  {
    id: 'solaris',
    name: 'SOLARIS APEX',
    role: 'Experimental Gold Craft',
    price: 3500,
    primaryColor: 0xffd700,
    accentColor: 0x00ffff,
    hullColor: 0x2d2312,
    speedBonus: 1.18,
    fireRateBonus: 1.38,
    handling: 1.25,
    cannons: 4,
    desc: 'Quad-plasma super-craft with built-in hyper-magnet and max speed.'
  }
];

export const UPGRADES = [
  { key: 'weapon', name: 'PLASMA CANNONS', icon: '⚡', maxLvl: 5, baseCost: 200, desc: 'Higher damage & faster plasma rate' },
  { key: 'nitro', name: 'HYPER-NITRO CORE', icon: '🔥', maxLvl: 5, baseCost: 220, desc: 'Longer unstoppable warp overdrive' },
  { key: 'shield', name: 'AEGIS SHIELD', icon: '🛡️', maxLvl: 5, baseCost: 250, desc: 'Extended invulnerability shield duration' },
  { key: 'magnet', name: 'CREDIT MAGNET', icon: '🧲', maxLvl: 5, baseCost: 180, desc: 'Pulls Neon Credits from across the highway' }
];

export const BIOMES = [
  {
    name: 'SECTOR 01: NEON METROPOLIS',
    fogColor: 0x070a1e,
    skyTop: 0x040614,
    skyHorizon: 0x1a0b38,
    sunColor: 0xff0088,
    primaryLight: 0x00f0ff,
    secondaryLight: 0xff00cc,
    archColor: 0x00f0ff
  },
  {
    name: 'SECTOR 02: SOLAR REACTOR',
    fogColor: 0x1a080c,
    skyTop: 0x0d0407,
    skyHorizon: 0x3b120c,
    sunColor: 0xffaa00,
    primaryLight: 0xff6600,
    secondaryLight: 0xffdd00,
    archColor: 0xff5500
  },
  {
    name: 'SECTOR 03: QUANTUM VOID',
    fogColor: 0x061614,
    skyTop: 0x020b0c,
    skyHorizon: 0x0a2e2c,
    sunColor: 0x00ffaa,
    primaryLight: 0x00ffaa,
    secondaryLight: 0x9933ff,
    archColor: 0x00ffaa
  }
];

const SAVE_KEY = 'neon_overdrive_3d_save_v2';

export function loadSave() {
  const defaults = {
    credits: 250,
    bestScore: 0,
    bestDist: 0,
    bossesDefeated: 0,
    selectedShip: 'viper',
    unlockedShips: ['viper'],
    upgrades: { weapon: 1, nitro: 1, shield: 1, magnet: 1 },
    muted: false,
    ultraBloom: true
  };
  try {
    const raw = localStorage.getItem(SAVE_KEY);
    if (!raw) return defaults;
    const parsed = JSON.parse(raw);
    return {
      ...defaults,
      ...parsed,
      upgrades: { ...defaults.upgrades, ...(parsed.upgrades || {}) },
      unlockedShips: Array.isArray(parsed.unlockedShips) && parsed.unlockedShips.length ? parsed.unlockedShips : ['viper']
    };
  } catch (e) {
    return defaults;
  }
}

export function persistSave(data) {
  try {
    localStorage.setItem(SAVE_KEY, JSON.stringify(data));
  } catch (e) {}
}

export function getUpgradeCost(upg, currentLvl) {
  return Math.round(upg.baseCost * Math.pow(1.75, currentLvl - 1));
}
