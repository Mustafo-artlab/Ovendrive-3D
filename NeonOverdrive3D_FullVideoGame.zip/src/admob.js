export const AdManager = (() => {
  const cfg = window.ADMOB_CONFIG || {
    isTesting: true,
    bannerAdId: 'ca-app-pub-3940256099942544/6300978111',
    interstitialAdId: 'ca-app-pub-3940256099942544/1033173712',
    rewardedAdId: 'ca-app-pub-3940256099942544/5224354917'
  };
  let plugin = null;
  let initialized = false;
  let bannerVisible = false;
  let runsSinceInterstitial = 0;

  async function init() {
    if (initialized) return;
    try {
      plugin = window.Capacitor && window.Capacitor.Plugins && window.Capacitor.Plugins.AdMob;
      if (!plugin) return;
      await plugin.initialize({ initializeForTesting: !!cfg.isTesting });
      initialized = true;
      prepareInterstitial();
      prepareRewarded();
      showBanner();
    } catch (e) {}
  }

  async function showBanner() {
    if (!initialized || !plugin || bannerVisible) return;
    try {
      await plugin.showBanner({
        adId: cfg.bannerAdId,
        adSize: 'ADAPTIVE_BANNER',
        position: 'BOTTOM_CENTER',
        margin: 0,
        isTesting: !!cfg.isTesting
      });
      bannerVisible = true;
    } catch (e) {}
  }

  async function hideBanner() {
    if (!initialized || !plugin || !bannerVisible) return;
    try {
      await plugin.hideBanner();
      bannerVisible = false;
    } catch (e) {}
  }

  async function prepareInterstitial() {
    if (!initialized || !plugin) return;
    try {
      await plugin.prepareInterstitial({ adId: cfg.interstitialAdId, isTesting: !!cfg.isTesting });
    } catch (e) {}
  }

  async function maybeShowInterstitial() {
    runsSinceInterstitial++;
    if (runsSinceInterstitial < 3) return;
    runsSinceInterstitial = 0;
    if (!initialized || !plugin) return;
    try {
      await plugin.showInterstitial();
      prepareInterstitial();
    } catch (e) {
      prepareInterstitial();
    }
  }

  async function prepareRewarded() {
    if (!initialized || !plugin) return;
    try {
      await plugin.prepareRewardVideoAd({ adId: cfg.rewardedAdId, isTesting: !!cfg.isTesting });
    } catch (e) {}
  }

  async function showRewarded(onReward) {
    if (initialized && plugin) {
      try {
        await plugin.showRewardVideoAd();
        prepareRewarded();
        onReward();
        return;
      } catch (e) {
        prepareRewarded();
      }
    }
    // Clean 3-second simulator when testing in browser/preview
    const modal = document.getElementById('adSimModal');
    const countEl = document.getElementById('adCountdown');
    if (!modal || !countEl) {
      onReward();
      return;
    }
    modal.classList.remove('hidden');
    let sec = 3;
    countEl.textContent = sec;
    const timer = setInterval(() => {
      sec--;
      if (sec <= 0) {
        clearInterval(timer);
        modal.classList.add('hidden');
        onReward();
      } else {
        countEl.textContent = sec;
      }
    }, 1000);
  }

  return { init, showBanner, hideBanner, maybeShowInterstitial, showRewarded };
})();
