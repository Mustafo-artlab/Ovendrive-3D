import * as THREE from 'three';
import { EffectComposer } from 'three/examples/jsm/postprocessing/EffectComposer.js';
import { RenderPass } from 'three/examples/jsm/postprocessing/RenderPass.js';
import { UnrealBloomPass } from 'three/examples/jsm/postprocessing/UnrealBloomPass.js';
import { OutputPass } from 'three/examples/jsm/postprocessing/OutputPass.js';
import { RoomEnvironment } from 'three/examples/jsm/environments/RoomEnvironment.js';

import { SHIPS, UPGRADES, BIOMES, loadSave, persistSave, getUpgradeCost } from './config.js';
import { AdManager } from './admob.js';
import { AudioEngine } from './audio.js';
import { buildPlayerShip, buildEnemyDrone, buildBossDreadnought } from './ships.js';

// ==================== SAVE STATE ====================
let save = loadSave();
AudioEngine.setMuted(save.muted);

// ==================== THREE.JS RENDERER & POST-PROCESSING ====================
const container = document.getElementById('canvasWrap');
const renderer = new THREE.WebGLRenderer({
  antialias: true,
  powerPreference: 'high-performance',
  stencil: false
});
renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 1.6));
renderer.setSize(window.innerWidth, window.innerHeight);
renderer.toneMapping = THREE.ACESFilmicToneMapping;
renderer.toneMappingExposure = 1.15;
renderer.outputColorSpace = THREE.SRGBColorSpace;
container.appendChild(renderer.domElement);

const scene = new THREE.Scene();
scene.background = new THREE.Color(BIOMES[0].fogColor);
scene.fog = new THREE.FogExp2(BIOMES[0].fogColor, 0.0085);

// Realistic Metallic Reflections via PMREM RoomEnvironment
const pmremGen = new THREE.PMREMGenerator(renderer);
scene.environment = pmremGen.fromScene(new RoomEnvironment(), 0.04).texture;

const camera = new THREE.PerspectiveCamera(64, window.innerWidth / window.innerHeight, 0.1, 260);
camera.position.set(0, 4.5, 11);

// HDR Unreal Bloom Post-Processing
const composer = new EffectComposer(renderer);
const renderPass = new RenderPass(scene, camera);
const bloomPass = new UnrealBloomPass(
  new THREE.Vector2(window.innerWidth, window.innerHeight),
  0.72,  // strength
  0.42,  // radius
  0.34   // threshold
);
const outputPass = new OutputPass();
composer.addPass(renderPass);
composer.addPass(bloomPass);
composer.addPass(outputPass);

window.addEventListener('resize', () => {
  const w = window.innerWidth;
  const h = window.innerHeight;
  camera.aspect = w / h;
  camera.updateProjectionMatrix();
  renderer.setSize(w, h);
  composer.setSize(w, h);
});

// ==================== LOAD HIGH-RES PBR TEXTURES ====================
const texLoader = new THREE.TextureLoader();
function loadTex(url, repeatX = 1, repeatY = 1, srgb = true) {
  const t = texLoader.load(url);
  t.wrapS = THREE.RepeatWrapping;
  t.wrapT = THREE.RepeatWrapping;
  t.repeat.set(repeatX, repeatY);
  if (srgb) t.colorSpace = THREE.SRGBColorSpace;
  t.anisotropy = Math.min(8, renderer.capabilities.getMaxAnisotropy());
  return t;
}

const textures = {
  highwayDiffuse: loadTex('assets/textures/highway_diffuse.png', 1, 14, true),
  highwayEmissive: loadTex('assets/textures/highway_emissive.png', 1, 14, true),
  highwayBump: loadTex('assets/textures/highway_bump.png', 1, 14, false),
  buildingDiffuse: loadTex('assets/textures/building_diffuse.png', 1, 3, true),
  buildingEmissive: loadTex('assets/textures/building_emissive.png', 1, 3, true),
  hullDiffuse: loadTex('assets/textures/hull_diffuse.png', 2, 2, true),
  hullBump: loadTex('assets/textures/hull_bump.png', 2, 2, false),
  hazardDiffuse: loadTex('assets/textures/hazard_diffuse.png', 2, 1, true)
};

// ==================== LIGHTING ====================
const hemiLight = new THREE.HemisphereLight(0x88ccff, 0x160a2e, 0.85);
scene.add(hemiLight);

const dirLight = new THREE.DirectionalLight(0xffffff, 1.35);
dirLight.position.set(12, 28, 16);
scene.add(dirLight);

const rimLight = new THREE.DirectionalLight(0xff00cc, 1.2);
rimLight.position.set(-16, 12, -20);
scene.add(rimLight);

// ==================== 3D CYBER-METROPOLIS ENVIRONMENT ====================
const ROAD_WIDTH = 17.5;
const ROAD_LEN = 260;

const roadMat = new THREE.MeshStandardMaterial({
  map: textures.highwayDiffuse,
  emissiveMap: textures.highwayEmissive,
  emissive: new THREE.Color(0xffffff),
  emissiveIntensity: 1.55,
  bumpMap: textures.highwayBump,
  bumpScale: 0.08,
  metalness: 0.72,
  roughness: 0.28
});
const roadMesh = new THREE.Mesh(new THREE.PlaneGeometry(ROAD_WIDTH, ROAD_LEN), roadMat);
roadMesh.rotation.x = -Math.PI / 2;
roadMesh.position.set(0, 0, -ROAD_LEN / 2 + 25);
scene.add(roadMesh);

// Glowing side guardrails
const railMatL = new THREE.MeshStandardMaterial({ color: 0x00f0ff, emissive: 0x00f0ff, emissiveIntensity: 2.2 });
const railMatR = new THREE.MeshStandardMaterial({ color: 0xff00cc, emissive: 0xff00cc, emissiveIntensity: 2.2 });
for (const side of [-1, 1]) {
  const rail = new THREE.Mesh(new THREE.BoxGeometry(0.28, 0.55, ROAD_LEN), side === -1 ? railMatL : railMatR);
  rail.position.set(side * (ROAD_WIDTH / 2 + 0.14), 0.28, -ROAD_LEN / 2 + 25);
  scene.add(rail);
}

// Retro-Futuristic Glowing Horizon Sun
const sunMat = new THREE.MeshBasicMaterial({ color: 0xff0088 });
const sunMesh = new THREE.Mesh(new THREE.CircleGeometry(34, 48), sunMat);
sunMesh.position.set(0, 32, -210);
scene.add(sunMesh);

// 3D Starfield / High-Speed Warp Dust
const starCount = 420;
const starGeo = new THREE.BufferGeometry();
const starPos = new Float32Array(starCount * 3);
for (let i = 0; i < starCount; i++) {
  starPos[i * 3] = (Math.random() - 0.5) * 140;
  starPos[i * 3 + 1] = 2 + Math.random() * 65;
  starPos[i * 3 + 2] = -Math.random() * 220;
}
starGeo.setAttribute('position', new THREE.BufferAttribute(starPos, 3));
const starMat = new THREE.PointsMaterial({ color: 0xaaf4ff, size: 0.45, transparent: true, opacity: 0.85 });
const starPoints = new THREE.Points(starGeo, starMat);
scene.add(starPoints);

// Towering 3D Cyberpunk Skyscrapers along both sides of the highway
const buildingMat = new THREE.MeshStandardMaterial({
  map: textures.buildingDiffuse,
  emissiveMap: textures.buildingEmissive,
  emissive: new THREE.Color(0xffffff),
  emissiveIntensity: 1.35,
  metalness: 0.78,
  roughness: 0.32
});
const buildings = [];
for (let i = 0; i < 44; i++) {
  const side = i % 2 === 0 ? -1 : 1;
  const bw = 7 + Math.random() * 9;
  const bh = 22 + Math.random() * 58;
  const bd = 8 + Math.random() * 10;
  const mesh = new THREE.Mesh(new THREE.BoxGeometry(bw, bh, bd), buildingMat);
  mesh.position.set(
    side * (ROAD_WIDTH / 2 + 7 + Math.random() * 18),
    bh / 2 - 14,
    -Math.floor(i / 2) * 11 - Math.random() * 5
  );
  scene.add(mesh);
  buildings.push(mesh);
}

// Glowing Overhead Neon Speed Arches
const archMat = new THREE.MeshStandardMaterial({
  color: 0x00f0ff,
  emissive: 0x00f0ff,
  emissiveIntensity: 2.3,
  metalness: 0.6,
  roughness: 0.2
});
const arches = [];
for (let i = 0; i < 9; i++) {
  const arch = new THREE.Group();
  const topBar = new THREE.Mesh(new THREE.BoxGeometry(ROAD_WIDTH + 1.4, 0.35, 0.55), archMat);
  topBar.position.y = 10.5;
  const leftPost = new THREE.Mesh(new THREE.BoxGeometry(0.42, 10.5, 0.55), archMat);
  leftPost.position.set(-(ROAD_WIDTH / 2 + 0.5), 5.25, 0);
  const rightPost = new THREE.Mesh(new THREE.BoxGeometry(0.42, 10.5, 0.55), archMat);
  rightPost.position.set(ROAD_WIDTH / 2 + 0.5, 5.25, 0);
  arch.add(topBar, leftPost, rightPost);
  arch.position.z = -i * 28 - 10;
  scene.add(arch);
  arches.push(arch);
}

// ==================== PLAYER SHIP MANAGEMENT ====================
let playerShip = null;
let currentShipSpec = SHIPS[0];

function getSelectedShipSpec() {
  return SHIPS.find(s => s.id === save.selectedShip) || SHIPS[0];
}

function mountPlayerShip(shipSpec) {
  if (playerShip) scene.remove(playerShip);
  currentShipSpec = shipSpec;
  playerShip = buildPlayerShip(shipSpec, textures);
  playerShip.position.set(0, 1.35, 0);
  scene.add(playerShip);
}
mountPlayerShip(getSelectedShipSpec());

// ==================== GAMEPLAY OBJECT POOLS ====================
const obstacles = [];
const collectibles = [];
const playerBullets = [];
const bossBullets = [];
const particles = [];

const barrierGeo = new THREE.BoxGeometry(3.8, 2.2, 1.4);
const pillarGeo = new THREE.BoxGeometry(2.1, 6.2, 2.1);
const coinGeo = new THREE.OctahedronGeometry(0.58, 0);
const powerGeo = new THREE.IcosahedronGeometry(0.72, 1);
const bulletGeo = new THREE.CapsuleGeometry(0.11, 0.95, 4, 8);
bulletGeo.rotateX(Math.PI / 2);
const bossShotGeo = new THREE.SphereGeometry(0.58, 12, 12);
const sparkGeo = new THREE.TetrahedronGeometry(0.28, 0);

const barrierMat = new THREE.MeshStandardMaterial({
  map: textures.hazardDiffuse,
  emissive: 0xff1e44,
  emissiveIntensity: 0.75,
  metalness: 0.6,
  roughness: 0.3
});
const pillarMat = new THREE.MeshStandardMaterial({
  color: 0x1e2545,
  map: textures.hullDiffuse,
  emissive: 0xff00aa,
  emissiveIntensity: 0.45,
  metalness: 0.85,
  roughness: 0.2
});
const coinMat = new THREE.MeshStandardMaterial({
  color: 0xffdd00,
  emissive: 0xffaa00,
  emissiveIntensity: 2.0,
  metalness: 0.9,
  roughness: 0.1
});
const shieldOrbMat = new THREE.MeshStandardMaterial({ color: 0x00ffaa, emissive: 0x00ffaa, emissiveIntensity: 2.5 });
const magnetOrbMat = new THREE.MeshStandardMaterial({ color: 0xb84dff, emissive: 0xb84dff, emissiveIntensity: 2.5 });
const nitroOrbMat = new THREE.MeshStandardMaterial({ color: 0xff6600, emissive: 0xff6600, emissiveIntensity: 2.8 });
const bossShotMat = new THREE.MeshBasicMaterial({ color: 0xff1a40 });

function spawnExplosion(pos, colorHex, count = 20, scale = 1.0) {
  const mat = new THREE.MeshBasicMaterial({ color: colorHex, transparent: true, opacity: 1 });
  for (let i = 0; i < count; i++) {
    const m = new THREE.Mesh(sparkGeo, mat.clone());
    m.position.copy(pos);
    m.scale.setScalar((0.6 + Math.random() * 1.1) * scale);
    const spd = (5 + Math.random() * 16) * scale;
    const theta = Math.random() * Math.PI * 2;
    const phi = (Math.random() - 0.35) * Math.PI;
    scene.add(m);
    particles.push({
      mesh: m,
      vx: Math.cos(theta) * Math.cos(phi) * spd,
      vy: Math.abs(Math.sin(phi)) * spd + 3,
      vz: Math.sin(theta) * Math.cos(phi) * spd + 6,
      life: 1.0,
      decay: 1.3 + Math.random() * 0.9
    });
  }
}

// ==================== GAME STATE VARIABLES ====================
let gameState = 'MENU'; // MENU, HANGAR, PLAY, OVER
let score = 0;
let distance = 0;
let runCredits = 0;
let combo = 1;
let comboTimer = 0;
let nitroCharge = 0; // 0 to 100
let nitroTime = 0;
let shieldTime = 0;
let magnetTime = 0;
let speed = 52;
let biomeIdx = 0;
let nextBossDist = 1100;
let bossActive = false;
let bossObj = null;
let bossHP = 0;
let bossMaxHP = 0;
let bossFireTimer = 0;
let usedRevive = false;
let usedDoubleCredits = false;

let targetX = 0;
let shipX = 0;
let shipVX = 0;
let fireTimer = 0;
let spawnTimer = 0;
let slowMoTimer = 0;
let camShake = 0;
let hangarOrbitAngle = 0;

function vibrate(pattern) {
  if (navigator.vibrate) navigator.vibrate(pattern);
}

function showCallout(text, color = '#00f5ff') {
  const el = document.getElementById('callout');
  el.textContent = text;
  el.style.color = color;
  el.style.textShadow = `0 0 22px ${color}`;
  el.classList.remove('pop');
  void el.offsetWidth;
  el.classList.add('pop');
}

function applyBiome(idx) {
  biomeIdx = idx % BIOMES.length;
  const b = BIOMES[biomeIdx];
  scene.background.setHex(b.fogColor);
  scene.fog.color.setHex(b.fogColor);
  sunMat.color.setHex(b.sunColor);
  archMat.color.setHex(b.archColor);
  archMat.emissive.setHex(b.archColor);
  rimLight.color.setHex(b.secondaryLight);
  showCallout(b.name, '#00f5ff');
}

function clearEntities() {
  for (const o of obstacles) scene.remove(o.mesh);
  obstacles.length = 0;
  for (const c of collectibles) scene.remove(c.mesh);
  collectibles.length = 0;
  for (const b of playerBullets) scene.remove(b.mesh);
  playerBullets.length = 0;
  for (const bs of bossBullets) scene.remove(bs.mesh);
  bossBullets.length = 0;
  if (bossObj) {
    scene.remove(bossObj);
    bossObj = null;
  }
  bossActive = false;
  document.getElementById('bossHud').classList.add('hidden');
}

function startRun() {
  AudioEngine.ensure();
  AudioEngine.startMusic();
  AudioEngine.setMode('PLAY');
  AdManager.hideBanner();

  clearEntities();
  mountPlayerShip(getSelectedShipSpec());
  score = 0;
  distance = 0;
  runCredits = 0;
  combo = 1;
  comboTimer = 0;
  nitroCharge = 35;
  nitroTime = 0;
  shieldTime = 2.0; // Brief launch shield
  magnetTime = currentShipSpec.id === 'solaris' ? 6.0 : 0;
  speed = 54 * currentShipSpec.speedBonus;
  nextBossDist = 1100;
  usedRevive = false;
  usedDoubleCredits = false;
  targetX = 0;
  shipX = 0;
  shipVX = 0;
  spawnTimer = 0.4;
  applyBiome(0);

  gameState = 'PLAY';
  document.getElementById('menuScreen').classList.add('hidden');
  document.getElementById('hangarScreen').classList.add('hidden');
  document.getElementById('gameOverScreen').classList.add('hidden');
  document.getElementById('hud').classList.remove('hidden');
  updateHUD();
}

function triggerNitro() {
  if (gameState !== 'PLAY') return;
  if (nitroCharge < 100 || nitroTime > 0) return;
  nitroCharge = 0;
  nitroTime = 4.2 + (save.upgrades.nitro - 1) * 0.85;
  camShake = 0.5;
  AudioEngine.playNitro();
  AudioEngine.setMode('NITRO');
  vibrate([30, 25, 70]);
  showCallout('🔥 HYPER-NITRO OVERDRIVE! 🔥', '#ffaa00');
}

function spawnWave() {
  const lanes = [-6.2, -3.1, 0, 3.1, 6.2];
  const zSpawn = -155;

  // Choose obstacle pattern
  const roll = Math.random();
  if (roll < 0.38) {
    // 1 or 2 Cyber-Drones (destructible with cannons!)
    const count = Math.random() < 0.45 ? 2 : 1;
    for (let k = 0; k < count; k++) {
      const laneX = lanes[Math.floor(Math.random() * lanes.length)];
      const drone = buildEnemyDrone(textures);
      drone.position.set(laneX, 1.55, zSpawn - k * 14);
      scene.add(drone);
      obstacles.push({
        type: 'drone',
        mesh: drone,
        hp: 2 + Math.floor(distance / 900),
        radius: 1.45,
        strafeSpeed: (Math.random() - 0.5) * 3.8,
        nearMissed: false
      });
    }
  } else if (roll < 0.74) {
    // Destructible Laser Barrier + Coin Line
    const laneIdx = Math.floor(Math.random() * lanes.length);
    const bx = lanes[laneIdx];
    const m = new THREE.Mesh(barrierGeo, barrierMat.clone());
    m.position.set(bx, 1.15, zSpawn);
    scene.add(m);
    obstacles.push({
      type: 'barrier',
      mesh: m,
      hp: 3 + Math.floor(distance / 1200),
      radius: 2.0,
      strafeSpeed: 0,
      nearMissed: false
    });
    // Safe lane coins
    const coinLane = lanes[(laneIdx + 2) % lanes.length];
    for (let c = 0; c < 4; c++) {
      const cm = new THREE.Mesh(coinGeo, coinMat);
      cm.position.set(coinLane, 1.35, zSpawn - c * 4.5);
      scene.add(cm);
      collectibles.push({ type: 'coin', mesh: cm });
    }
  } else {
    // Twin Tall Cyber Pillars (Narrow gap for Near-Miss dopamine!)
    const safeIdx = 1 + Math.floor(Math.random() * 3);
    for (let i = 0; i < lanes.length; i++) {
      if (Math.abs(i - safeIdx) <= 0) continue;
      if (Math.random() < 0.62) {
        const pm = new THREE.Mesh(pillarGeo, pillarMat);
        pm.position.set(lanes[i], 3.1, zSpawn);
        scene.add(pm);
        obstacles.push({
          type: 'pillar',
          mesh: pm,
          hp: 999, // Indestructible unless in Nitro!
          radius: 1.45,
          strafeSpeed: 0,
          nearMissed: false
        });
      }
    }
    // Rewarding powerup or coins in the safe gap
    if (Math.random() < 0.24) {
      const types = ['shield', 'magnet', 'nitro'];
      const pType = types[Math.floor(Math.random() * types.length)];
      const mat = pType === 'shield' ? shieldOrbMat : (pType === 'magnet' ? magnetOrbMat : nitroOrbMat);
      const orb = new THREE.Mesh(powerGeo, mat);
      orb.position.set(lanes[safeIdx], 1.5, zSpawn - 3);
      scene.add(orb);
      collectibles.push({ type: pType, mesh: orb });
    } else {
      for (let c = 0; c < 3; c++) {
        const cm = new THREE.Mesh(coinGeo, coinMat);
        cm.position.set(lanes[safeIdx], 1.35, zSpawn - c * 4.2);
        scene.add(cm);
        collectibles.push({ type: 'coin', mesh: cm });
      }
    }
  }
}

function spawnBoss() {
  bossActive = true;
  bossMaxHP = 38 + save.bossesDefeated * 18 + Math.floor(distance / 80);
  bossHP = bossMaxHP;
  bossFireTimer = 1.6;
  bossObj = buildBossDreadnought(textures, biomeIdx);
  bossObj.position.set(0, 14, -70);
  scene.add(bossObj);

  AudioEngine.playBossAlarm();
  AudioEngine.setMode('BOSS');
  vibrate([80, 60, 80, 60, 120]);
  showCallout('⚠️ WARNING: DREADNOUGHT BOSS! ⚠️', '#ff2255');
  document.getElementById('bossHud').classList.remove('hidden');
  document.getElementById('bossBar').style.width = '100%';
}

function defeatBoss() {
  if (!bossObj) return;
  const bPos = bossObj.position.clone();
  spawnExplosion(bPos, 0xffaa00, 48, 2.2);
  spawnExplosion(bPos, 0xff0066, 36, 1.8);
  spawnExplosion(bPos, 0x00ffff, 30, 1.5);
  scene.remove(bossObj);
  bossObj = null;
  bossActive = false;
  document.getElementById('bossHud').classList.add('hidden');

  for (const bs of bossBullets) scene.remove(bs.mesh);
  bossBullets.length = 0;

  save.bossesDefeated++;
  runCredits += 300;
  score += 2500 * combo;
  nitroCharge = 100;
  camShake = 0.9;
  slowMoTimer = 0.45;
  nextBossDist = distance + 1350;

  AudioEngine.playExplosion(true);
  AudioEngine.playPowerup();
  AudioEngine.setMode(nitroTime > 0 ? 'NITRO' : 'PLAY');
  vibrate([100, 50, 160]);
  showCallout('💥 BOSS DESTROYED! +300 ◈ 💥', '#ffdd00');

  setTimeout(() => {
    if (gameState === 'PLAY') applyBiome(biomeIdx + 1);
  }, 1600);
}

function firePlayerCannons() {
  const cannonCount = currentShipSpec.cannons;
  const dmg = 1 + (save.upgrades.weapon - 1) * 0.55;
  const offsets = cannonCount === 4
    ? [-1.15, -0.45, 0.45, 1.15]
    : (cannonCount === 3 ? [-0.95, 0, 0.95] : [-0.88, 0.88]);

  const bCol = nitroTime > 0 ? 0xffdd00 : currentShipSpec.primaryColor;
  const bMat = new THREE.MeshBasicMaterial({ color: bCol });

  for (const ox of offsets) {
    const bm = new THREE.Mesh(bulletGeo, bMat);
    bm.position.set(playerShip.position.x + ox, playerShip.position.y - 0.05, -1.2);
    scene.add(bm);
    playerBullets.push({ mesh: bm, dmg });
  }
  AudioEngine.playLaser(cannonCount >= 3);
}

function triggerCrash() {
  if (nitroTime > 0 || shieldTime > 0) return;

  gameState = 'OVER';
  AudioEngine.playExplosion(true);
  AudioEngine.setMode('MENU');
  vibrate([120, 40, 180]);
  camShake = 0.85;
  spawnExplosion(playerShip.position, currentShipSpec.primaryColor, 36, 1.4);
  spawnExplosion(playerShip.position, 0xff4400, 28, 1.2);
  playerShip.visible = false;

  save.credits += runCredits;
  if (score > save.bestScore) save.bestScore = Math.floor(score);
  if (distance > save.bestDist) save.bestDist = Math.floor(distance);
  persistSave(save);

  document.getElementById('hud').classList.add('hidden');
  document.getElementById('goScore').textContent = Math.floor(score).toLocaleString();
  document.getElementById('goBest').textContent = save.bestScore.toLocaleString();
  document.getElementById('goDist').textContent = Math.floor(distance) + 'm';
  document.getElementById('goCredits').textContent = '+' + runCredits + ' ◈';
  document.getElementById('reviveBtn').style.display = usedRevive ? 'none' : 'block';
  document.getElementById('doubleCreditsBtn').style.display = (runCredits > 0 && !usedDoubleCredits) ? 'block' : 'none';
  document.getElementById('gameOverScreen').classList.remove('hidden');

  AdManager.showBanner();
  AdManager.maybeShowInterstitial();
}

function revivePlayer() {
  usedRevive = true;
  // Clear nearby hazards & give 3.5s Aegis Shield
  for (let i = obstacles.length - 1; i >= 0; i--) {
    if (obstacles[i].mesh.position.z > -45) {
      spawnExplosion(obstacles[i].mesh.position, 0x00ffaa, 12, 0.9);
      scene.remove(obstacles[i].mesh);
      obstacles.splice(i, 1);
    }
  }
  for (const bs of bossBullets) scene.remove(bs.mesh);
  bossBullets.length = 0;

  // Roll back banked run credits so they aren't double-counted on second crash
  save.credits = Math.max(0, save.credits - runCredits);
  persistSave(save);

  playerShip.visible = true;
  shieldTime = 3.5 + (save.upgrades.shield - 1) * 0.7;
  gameState = 'PLAY';
  document.getElementById('gameOverScreen').classList.add('hidden');
  document.getElementById('hud').classList.remove('hidden');
  AdManager.hideBanner();
  AudioEngine.setMode(bossActive ? 'BOSS' : 'PLAY');
  AudioEngine.playPowerup();
  showCallout('🛡️ AEGIS SHIELD REVIVE!', '#00ffaa');
}

// ==================== HUD & HANGAR UI ====================
function updateHUD() {
  document.getElementById('scoreVal').textContent = Math.floor(score).toLocaleString();
  document.getElementById('distVal').textContent = Math.floor(distance) + 'm';
  document.getElementById('creditsHud').textContent = '◈ ' + (save.credits + runCredits);

  const comboEl = document.getElementById('comboPill');
  if (combo > 1) {
    comboEl.textContent = 'COMBO x' + combo;
    comboEl.style.opacity = '1';
  } else {
    comboEl.style.opacity = '0';
  }

  const nitroPct = nitroTime > 0 ? Math.min(100, (nitroTime / (4.2 + (save.upgrades.nitro - 1) * 0.85)) * 100) : nitroCharge;
  document.getElementById('nitroFill').style.width = nitroPct + '%';

  const nitroBtn = document.getElementById('nitroBtn');
  if (nitroCharge >= 100 && nitroTime <= 0) {
    nitroBtn.classList.add('ready');
    nitroBtn.textContent = '🔥 ACTIVATE NITRO';
  } else if (nitroTime > 0) {
    nitroBtn.classList.add('ready');
    nitroBtn.textContent = '⚡ HYPER-WARP!';
  } else {
    nitroBtn.classList.remove('ready');
    nitroBtn.textContent = 'NITRO ' + Math.floor(nitroCharge) + '%';
  }

  const shieldTag = document.getElementById('shieldTag');
  shieldTag.style.display = shieldTime > 0 ? 'inline-block' : 'none';
  if (shieldTime > 0) shieldTag.textContent = '🛡️ ' + shieldTime.toFixed(1) + 's';

  const magTag = document.getElementById('magnetTag');
  magTag.style.display = magnetTime > 0 ? 'inline-block' : 'none';
  if (magnetTime > 0) magTag.textContent = '🧲 ' + magnetTime.toFixed(1) + 's';
}

function updateMenuStats() {
  document.getElementById('menuCredits').textContent = '◈ ' + save.credits.toLocaleString();
  document.getElementById('menuBest').textContent = 'BEST ' + save.bestScore.toLocaleString();
  document.getElementById('muteBtn').textContent = save.muted ? '🔇' : '🔊';
  document.getElementById('bloomBtn').textContent = save.ultraBloom ? '✨ ULTRA 3D' : '⚡ 60FPS';
}

let previewShipIdx = SHIPS.findIndex(s => s.id === save.selectedShip);
if (previewShipIdx < 0) previewShipIdx = 0;

function renderHangarUI() {
  document.getElementById('hangarCredits').textContent = '◈ ' + save.credits.toLocaleString();
  const s = SHIPS[previewShipIdx];
  mountPlayerShip(s);

  document.getElementById('shipName').textContent = s.name;
  document.getElementById('shipRole').textContent = `${s.role} • ${s.cannons}x Plasma Cannons`;
  document.getElementById('shipDesc').textContent = s.desc;

  const isUnlocked = save.unlockedShips.includes(s.id);
  const isSelected = save.selectedShip === s.id;
  const actBtn = document.getElementById('shipActionBtn');
  if (isSelected) {
    actBtn.textContent = '✓ EQUIPPED';
    actBtn.className = 'btn btn-ghost';
  } else if (isUnlocked) {
    actBtn.textContent = 'SELECT SHIP';
    actBtn.className = 'btn btn-primary';
  } else {
    actBtn.textContent = `UNLOCK FOR ◈ ${s.price}`;
    actBtn.className = save.credits >= s.price ? 'btn btn-ad' : 'btn btn-ghost';
  }

  // Render upgrade cards
  const list = document.getElementById('upgradeList');
  list.innerHTML = '';
  for (const u of UPGRADES) {
    const lvl = save.upgrades[u.key] || 1;
    const maxed = lvl >= u.maxLvl;
    const cost = getUpgradeCost(u, lvl);
    const row = document.createElement('div');
    row.className = 'upg-row';
    row.innerHTML = `
      <div class="upg-info">
        <div class="upg-title">${u.icon} ${u.name} <span>LVL ${lvl}/${u.maxLvl}</span></div>
        <div class="upg-desc">${u.desc}</div>
      </div>
      <button class="upg-btn ${maxed ? 'maxed' : (save.credits >= cost ? 'can-buy' : '')}">
        ${maxed ? 'MAX' : '◈ ' + cost}
      </button>
    `;
    const btn = row.querySelector('button');
    btn.addEventListener('click', () => {
      if (maxed) return;
      if (save.credits < cost) {
        showCallout('NEED MORE CREDITS!', '#ff3366');
        return;
      }
      AudioEngine.playPowerup();
      save.credits -= cost;
      save.upgrades[u.key] = lvl + 1;
      persistSave(save);
      renderHangarUI();
      updateMenuStats();
    });
    list.appendChild(row);
  }
}

// ==================== CONTROLS (TOUCH DRAG + DOUBLE TAP + KEYBOARD) ====================
let isDragging = false;
let lastPointerX = 0;
let lastTapTime = 0;

function onPointerDown(e) {
  if (gameState !== 'PLAY') return;
  if (e.target.closest('button')) return;
  isDragging = true;
  lastPointerX = e.clientX;
  const now = performance.now();
  if (now - lastTapTime < 280) {
    triggerNitro();
  }
  lastTapTime = now;
}

function onPointerMove(e) {
  if (!isDragging || gameState !== 'PLAY') return;
  const dx = e.clientX - lastPointerX;
  lastPointerX = e.clientX;
  const sensitivity = (18.5 / Math.max(320, window.innerWidth)) * currentShipSpec.handling;
  targetX = Math.max(-7.4, Math.min(7.4, targetX + dx * sensitivity));
}

function onPointerUp() {
  isDragging = false;
}

window.addEventListener('pointerdown', onPointerDown);
window.addEventListener('pointermove', onPointerMove);
window.addEventListener('pointerup', onPointerUp);
window.addEventListener('pointercancel', onPointerUp);

const keys = {};
window.addEventListener('keydown', (e) => {
  keys[e.code] = true;
  if (e.code === 'Space' && gameState === 'PLAY') triggerNitro();
});
window.addEventListener('keyup', (e) => { keys[e.code] = false; });

// Button Bindings
document.getElementById('playBtn').addEventListener('click', () => {
  AudioEngine.playClick();
  AdManager.init();
  startRun();
});

document.getElementById('openHangarBtn').addEventListener('click', () => {
  AudioEngine.playClick();
  AdManager.init();
  gameState = 'HANGAR';
  document.getElementById('menuScreen').classList.add('hidden');
  document.getElementById('hangarScreen').classList.remove('hidden');
  previewShipIdx = Math.max(0, SHIPS.findIndex(s => s.id === save.selectedShip));
  renderHangarUI();
});

document.getElementById('closeHangarBtn').addEventListener('click', () => {
  AudioEngine.playClick();
  mountPlayerShip(getSelectedShipSpec());
  gameState = 'MENU';
  document.getElementById('hangarScreen').classList.add('hidden');
  document.getElementById('menuScreen').classList.remove('hidden');
  updateMenuStats();
});

document.getElementById('prevShipBtn').addEventListener('click', () => {
  AudioEngine.playClick();
  previewShipIdx = (previewShipIdx - 1 + SHIPS.length) % SHIPS.length;
  renderHangarUI();
});

document.getElementById('nextShipBtn').addEventListener('click', () => {
  AudioEngine.playClick();
  previewShipIdx = (previewShipIdx + 1) % SHIPS.length;
  renderHangarUI();
});

document.getElementById('shipActionBtn').addEventListener('click', () => {
  const s = SHIPS[previewShipIdx];
  if (save.unlockedShips.includes(s.id)) {
    AudioEngine.playPowerup();
    save.selectedShip = s.id;
    persistSave(save);
    renderHangarUI();
  } else if (save.credits >= s.price) {
    AudioEngine.playPowerup();
    save.credits -= s.price;
    save.unlockedShips.push(s.id);
    save.selectedShip = s.id;
    persistSave(save);
    renderHangarUI();
    updateMenuStats();
    showCallout('🚀 ' + s.name + ' UNLOCKED!', '#ffdd00');
  } else {
    showCallout('NEED ' + s.price + ' CREDITS!', '#ff3366');
  }
});

document.getElementById('freeCreditsAdBtn').addEventListener('click', () => {
  AudioEngine.playClick();
  AdManager.showRewarded(() => {
    save.credits += 500;
    persistSave(save);
    AudioEngine.playPowerup();
    renderHangarUI();
    updateMenuStats();
    showCallout('+500 ◈ SUPPLY DROP!', '#ffdd00');
  });
});

document.getElementById('nitroBtn').addEventListener('click', (e) => {
  e.stopPropagation();
  triggerNitro();
});

document.getElementById('reviveBtn').addEventListener('click', () => {
  AudioEngine.playClick();
  AdManager.showRewarded(() => revivePlayer());
});

document.getElementById('doubleCreditsBtn').addEventListener('click', () => {
  AudioEngine.playClick();
  AdManager.showRewarded(() => {
    usedDoubleCredits = true;
    save.credits += runCredits;
    persistSave(save);
    AudioEngine.playPowerup();
    document.getElementById('goCredits').textContent = '+' + (runCredits * 2) + ' ◈ (2X!)';
    document.getElementById('doubleCreditsBtn').style.display = 'none';
    updateMenuStats();
  });
});

document.getElementById('retryBtn').addEventListener('click', () => {
  AudioEngine.playClick();
  startRun();
});

document.getElementById('backMenuBtn').addEventListener('click', () => {
  AudioEngine.playClick();
  clearEntities();
  playerShip.visible = true;
  mountPlayerShip(getSelectedShipSpec());
  gameState = 'MENU';
  document.getElementById('gameOverScreen').classList.add('hidden');
  document.getElementById('menuScreen').classList.remove('hidden');
  updateMenuStats();
});

document.getElementById('muteBtn').addEventListener('click', () => {
  save.muted = !save.muted;
  AudioEngine.setMuted(save.muted);
  persistSave(save);
  updateMenuStats();
});

document.getElementById('bloomBtn').addEventListener('click', () => {
  save.ultraBloom = !save.ultraBloom;
  persistSave(save);
  updateMenuStats();
});

// ==================== MAIN 60 FPS GAME LOOP ====================
let lastTime = performance.now();

function animate(now) {
  requestAnimationFrame(animate);
  let rawDt = Math.min((now - lastTime) / 1000, 0.05);
  lastTime = now;

  if (slowMoTimer > 0) {
    slowMoTimer = Math.max(0, slowMoTimer - rawDt);
    rawDt *= 0.38;
  }
  const dt = rawDt;

  // Scroll Highway, Buildings, Arches & Stars
  const activeSpeed = gameState === 'PLAY' ? (nitroTime > 0 ? speed * 1.95 : speed) : 22;
  textures.highwayDiffuse.offset.y -= activeSpeed * dt * 0.035;
  textures.highwayEmissive.offset.y = textures.highwayDiffuse.offset.y;
  textures.highwayBump.offset.y = textures.highwayDiffuse.offset.y;

  for (const b of buildings) {
    b.position.z += activeSpeed * dt;
    if (b.position.z > 28) b.position.z -= 242;
  }
  for (const a of arches) {
    a.position.z += activeSpeed * dt;
    if (a.position.z > 22) a.position.z -= 252;
  }

  const spArr = starGeo.attributes.position.array;
  for (let i = 0; i < starCount; i++) {
    spArr[i * 3 + 2] += activeSpeed * dt * 1.3;
    if (spArr[i * 3 + 2] > 18) spArr[i * 3 + 2] = -215;
  }
  starGeo.attributes.position.needsUpdate = true;

  // Animate Ship Thrusters
  if (playerShip && playerShip.userData) {
    const { thrusters, shieldMesh, engineLight, flameMat } = playerShip.userData;
    const pulse = (nitroTime > 0 ? 1.85 : 1.0) + Math.sin(now * 0.04) * 0.22;
    for (const fl of thrusters) {
      fl.scale.set(nitroTime > 0 ? 1.45 : 1.0, nitroTime > 0 ? 1.45 : 1.0, pulse);
    }
    flameMat.color.setHex(nitroTime > 0 ? 0xffbb00 : currentShipSpec.primaryColor);
    engineLight.color.setHex(nitroTime > 0 ? 0xffaa00 : currentShipSpec.primaryColor);
    engineLight.intensity = nitroTime > 0 ? 11.0 : 5.5;
    shieldMesh.visible = shieldTime > 0 || nitroTime > 0;
    if (shieldMesh.visible) {
      shieldMesh.rotation.y += dt * 2.5;
      shieldMesh.rotation.x += dt * 1.4;
      shieldMesh.material.color.setHex(nitroTime > 0 ? 0xffaa00 : 0x00ffaa);
    }
  }

  if (gameState === 'MENU' || gameState === 'HANGAR') {
    hangarOrbitAngle += dt * 0.65;
    playerShip.visible = true;
    playerShip.position.set(0, 1.8 + Math.sin(now * 0.003) * 0.25, 0);
    playerShip.rotation.set(0.06, hangarOrbitAngle, Math.sin(hangarOrbitAngle) * 0.08);
    const camDist = gameState === 'HANGAR' ? 6.4 : 7.8;
    const camY = gameState === 'HANGAR' ? 3.2 : 3.6;
    camera.position.lerp(new THREE.Vector3(0, camY, camDist), Math.min(1, dt * 6));
    camera.lookAt(0, 1.4, 0);
    camera.fov += (60 - camera.fov) * 0.1;
    camera.updateProjectionMatrix();
  } else if (gameState === 'PLAY') {
    // Keyboard assist
    if (keys['ArrowLeft'] || keys['KeyA']) targetX = Math.max(-7.4, targetX - 16 * dt * currentShipSpec.handling);
    if (keys['ArrowRight'] || keys['KeyD']) targetX = Math.min(7.4, targetX + 16 * dt * currentShipSpec.handling);

    // Smooth Ship Steering & Realistic Roll Banking
    const prevX = shipX;
    shipX += (targetX - shipX) * Math.min(1, dt * 14 * currentShipSpec.handling);
    shipVX = (shipX - prevX) / Math.max(0.001, dt);
    playerShip.position.set(shipX, 1.35 + Math.sin(now * 0.007) * 0.1, 0);
    playerShip.rotation.z = THREE.MathUtils.clamp(-shipVX * 0.055, -0.68, 0.68);
    playerShip.rotation.y = THREE.MathUtils.clamp(-shipVX * 0.015, -0.18, 0.18);
    playerShip.rotation.x = nitroTime > 0 ? -0.12 : 0.02;

    // Dynamic Camera Follow + FOV Warp during Nitro
    const targetFov = nitroTime > 0 ? 86 : 64 + Math.min(10, (speed - 54) * 0.2);
    camera.fov += (targetFov - camera.fov) * Math.min(1, dt * 6);
    camera.updateProjectionMatrix();

    const shakeX = camShake > 0 ? (Math.random() - 0.5) * camShake : 0;
    const shakeY = camShake > 0 ? (Math.random() - 0.5) * camShake : 0;
    camera.position.set(shipX * 0.45 + shakeX, 4.4 + (nitroTime > 0 ? 0.5 : 0) + shakeY, nitroTime > 0 ? 11.8 : 9.8);
    camera.lookAt(shipX * 0.28, 1.5, -24);

    // Progress, Timers & Speed Ramp
    distance += activeSpeed * dt * 0.55;
    score += activeSpeed * dt * 0.65 * combo;
    speed = Math.min(115, (54 + distance * 0.012) * currentShipSpec.speedBonus);

    if (nitroTime > 0) {
      nitroTime = Math.max(0, nitroTime - dt);
      if (nitroTime === 0) AudioEngine.setMode(bossActive ? 'BOSS' : 'PLAY');
    } else {
      nitroCharge = Math.min(100, nitroCharge + dt * 2.8);
    }
    if (shieldTime > 0) shieldTime = Math.max(0, shieldTime - dt);
    if (magnetTime > 0) magnetTime = Math.max(0, magnetTime - dt);
    if (comboTimer > 0) {
      comboTimer -= dt;
      if (comboTimer <= 0) combo = 1;
    }

    // Auto-Firing Plasma Cannons
    fireTimer -= dt;
    const fireInterval = (0.24 / currentShipSpec.fireRateBonus) * Math.pow(0.88, save.upgrades.weapon - 1);
    if (fireTimer <= 0) {
      fireTimer = nitroTime > 0 ? fireInterval * 0.65 : fireInterval;
      firePlayerCannons();
    }

    // Boss Spawn Trigger
    if (!bossActive && distance >= nextBossDist) {
      spawnBoss();
    }

    // Regular Wave Spawning (pauses during Boss Fight)
    if (!bossActive) {
      spawnTimer -= dt;
      if (spawnTimer <= 0) {
        spawnWave();
        spawnTimer = Math.max(0.42, 1.15 - (speed - 54) * 0.008);
      }
    }

    // Update Player Bullets
    for (let i = playerBullets.length - 1; i >= 0; i--) {
      const b = playerBullets[i];
      b.mesh.position.z -= 165 * dt;
      let hit = false;

      // Hit Boss
      if (bossActive && bossObj) {
        const dx = Math.abs(b.mesh.position.x - bossObj.position.x);
        const dz = Math.abs(b.mesh.position.z - bossObj.position.z);
        if (dx < 5.6 && dz < 3.6) {
          hit = true;
          bossHP -= b.dmg;
          spawnExplosion(b.mesh.position, 0xffaa00, 5, 0.55);
          document.getElementById('bossBar').style.width = Math.max(0, (bossHP / bossMaxHP) * 100) + '%';
          if (bossHP <= 0) defeatBoss();
        }
      }

      // Hit Obstacles/Drones
      if (!hit) {
        for (let j = obstacles.length - 1; j >= 0; j--) {
          const o = obstacles[j];
          const dx = Math.abs(b.mesh.position.x - o.mesh.position.x);
          const dz = Math.abs(b.mesh.position.z - o.mesh.position.z);
          if (dx < o.radius + 0.5 && dz < 1.8) {
            hit = true;
            if (o.hp < 500) {
              o.hp -= b.dmg;
              spawnExplosion(b.mesh.position, 0x00ffff, 4, 0.45);
              if (o.hp <= 0) {
                spawnExplosion(o.mesh.position, o.type === 'drone' ? 0xff1e4d : 0xff8800, 18, 1.0);
                AudioEngine.playExplosion(false);
                camShake = Math.max(camShake, 0.22);
                score += 120 * combo;
                runCredits += o.type === 'drone' ? 15 : 8;
                nitroCharge = Math.min(100, nitroCharge + 6);
                scene.remove(o.mesh);
                obstacles.splice(j, 1);
              }
            }
            break;
          }
        }
      }

      if (hit || b.mesh.position.z < -150) {
        scene.remove(b.mesh);
        playerBullets.splice(i, 1);
      }
    }

    // Update Boss AI & Attacks
    if (bossActive && bossObj) {
      bossObj.position.z += (-30 - bossObj.position.z) * Math.min(1, dt * 3.5);
      bossObj.position.y += (3.8 - bossObj.position.y) * Math.min(1, dt * 3.5);
      bossObj.position.x = Math.sin(now * 0.0014) * 5.2;
      bossObj.userData.reactorRing.rotation.z += dt * 3.2;
      bossObj.userData.heart.rotation.y += dt * 2.4;

      bossFireTimer -= dt;
      if (bossFireTimer <= 0 && bossObj.position.z > -38) {
        bossFireTimer = Math.max(0.65, 1.35 - save.bossesDefeated * 0.08);
        // Fire dual plasma orbs aimed toward player's side
        for (const side of [-1, 1]) {
          const shot = new THREE.Mesh(bossShotGeo, bossShotMat);
          shot.position.set(bossObj.position.x + side * 4.4, 1.5, bossObj.position.z + 3.5);
          scene.add(shot);
          const aimX = (playerShip.position.x - shot.position.x) * 0.25;
          bossBullets.push({ mesh: shot, vx: aimX, vz: 44 + save.bossesDefeated * 4 });
        }
        AudioEngine.playLaser(true);
      }
    }

    // Update Boss Shots
    for (let i = bossBullets.length - 1; i >= 0; i--) {
      const bs = bossBullets[i];
      bs.mesh.position.x += bs.vx * dt;
      bs.mesh.position.z += bs.vz * dt;
      const dist = Math.hypot(bs.mesh.position.x - shipX, bs.mesh.position.z - 0);
      if (dist < 1.55) {
        scene.remove(bs.mesh);
        bossBullets.splice(i, 1);
        if (nitroTime > 0 || shieldTime > 0) {
          spawnExplosion(playerShip.position, 0x00ffaa, 12, 0.8);
          AudioEngine.playExplosion(false);
        } else {
          triggerCrash();
          break;
        }
        continue;
      }
      if (bs.mesh.position.z > 14) {
        scene.remove(bs.mesh);
        bossBullets.splice(i, 1);
      }
    }

    // Update Obstacles & NEAR-MISS System
    for (let i = obstacles.length - 1; i >= 0; i--) {
      const o = obstacles[i];
      o.mesh.position.z += activeSpeed * dt;
      if (o.type === 'drone') {
        o.mesh.position.x = THREE.MathUtils.clamp(o.mesh.position.x + o.strafeSpeed * dt, -7.0, 7.0);
        if (Math.abs(o.mesh.position.x) >= 6.9) o.strafeSpeed *= -1;
        o.mesh.userData.ring.rotation.z += dt * 4.5;
        o.mesh.userData.core.rotation.y += dt * 2.8;
      }

      const dx = Math.abs(o.mesh.position.x - shipX);
      const dz = o.mesh.position.z;

      // Direct Collision Check
      if (Math.abs(dz) < 1.75 && dx < o.radius + 0.55) {
        if (nitroTime > 0 || shieldTime > 0) {
          // Smash right through!
          spawnExplosion(o.mesh.position, nitroTime > 0 ? 0xffaa00 : 0x00ffaa, 22, 1.2);
          AudioEngine.playExplosion(false);
          camShake = 0.32;
          score += 150 * combo;
          runCredits += 10;
          vibrate(25);
          scene.remove(o.mesh);
          obstacles.splice(i, 1);
          continue;
        } else {
          triggerCrash();
          break;
        }
      }

      // NEAR-MISS OVERDRIVE TRIGGER!
      if (!o.nearMissed && dz > 1.2 && dz < 4.5 && dx >= o.radius + 0.55 && dx < o.radius + 2.45) {
        o.nearMissed = true;
        combo = Math.min(20, combo + 1);
        comboTimer = 4.2;
        score += 200 * combo;
        nitroCharge = Math.min(100, nitroCharge + 14);
        slowMoTimer = 0.085;
        camShake = 0.14;
        AudioEngine.playNearMiss(combo);
        vibrate(15);
        spawnExplosion(new THREE.Vector3((shipX + o.mesh.position.x) * 0.5, 1.4, 0), 0x00ffff, 10, 0.7);
        showCallout(`⚡ NEAR MISS! x${combo}`, '#00f5ff');
      }

      if (dz > 16) {
        scene.remove(o.mesh);
        obstacles.splice(i, 1);
      }
    }

    // Update Collectibles (Coins & Power-ups)
    const magRadius = (magnetTime > 0 ? 14.5 : 3.2) + (save.upgrades.magnet - 1) * 1.2;
    for (let i = collectibles.length - 1; i >= 0; i--) {
      const c = collectibles[i];
      c.mesh.position.z += activeSpeed * dt;
      c.mesh.rotation.y += dt * 3.8;

      const dx = shipX - c.mesh.position.x;
      const dz = 0 - c.mesh.position.z;
      const d = Math.hypot(dx, dz);

      if (c.type === 'coin' && d < magRadius && c.mesh.position.z > -24) {
        c.mesh.position.x += dx * Math.min(1, dt * 12);
        c.mesh.position.z += dz * Math.min(1, dt * 12);
      }

      if (d < 1.95) {
        if (c.type === 'coin') {
          runCredits += 5;
          score += 50 * combo;
          AudioEngine.playCoin(combo);
        } else if (c.type === 'shield') {
          shieldTime = 5.5 + (save.upgrades.shield - 1) * 1.1;
          AudioEngine.playPowerup();
          showCallout('🛡️ AEGIS SHIELD!', '#00ffaa');
        } else if (c.type === 'magnet') {
          magnetTime = 7.0 + (save.upgrades.magnet - 1) * 1.5;
          AudioEngine.playPowerup();
          showCallout('🧲 HYPER MAGNET!', '#c066ff');
        } else if (c.type === 'nitro') {
          nitroCharge = 100;
          AudioEngine.playPowerup();
          showCallout('🔥 NITRO FULL!', '#ff8800');
        }
        vibrate(10);
        scene.remove(c.mesh);
        collectibles.splice(i, 1);
        continue;
      }

      if (c.mesh.position.z > 14) {
        scene.remove(c.mesh);
        collectibles.splice(i, 1);
      }
    }

    updateHUD();
  }

  // Update 3D Explosion Particles
  for (let i = particles.length - 1; i >= 0; i--) {
    const p = particles[i];
    p.mesh.position.x += p.vx * dt;
    p.mesh.position.y += p.vy * dt;
    p.mesh.position.z += p.vz * dt;
    p.vy -= 18 * dt;
    p.mesh.rotation.x += 7 * dt;
    p.mesh.rotation.y += 6 * dt;
    p.life -= p.decay * dt;
    p.mesh.material.opacity = Math.max(0, p.life);
    if (p.life <= 0) {
      scene.remove(p.mesh);
      p.mesh.material.dispose();
      particles.splice(i, 1);
    }
  }

  camShake *= 0.86;
  if (camShake < 0.005) camShake = 0;

  // Render Frame (Ultra HDR Bloom or Direct 60FPS)
  if (save.ultraBloom) {
    composer.render();
  } else {
    renderer.render(scene, camera);
  }
}

updateMenuStats();
AdManager.init();
requestAnimationFrame(animate);
