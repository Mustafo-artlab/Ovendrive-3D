import { build } from 'esbuild';

await build({
  entryPoints: ['src/main.js'],
  bundle: true,
  minify: true,
  format: 'iife',
  target: ['es2020', 'chrome80'],
  outfile: 'www/game.bundle.js',
  logLevel: 'info'
});
console.log('Successfully bundled Three.js 3D Video Game -> www/game.bundle.js');
