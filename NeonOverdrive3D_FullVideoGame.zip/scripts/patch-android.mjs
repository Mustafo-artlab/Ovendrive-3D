import fs from 'fs';
import path from 'path';

const cfg = JSON.parse(fs.readFileSync('admob-config.json', 'utf8'));

// 1. Patch AndroidManifest.xml
const manifestPath = 'android/app/src/main/AndroidManifest.xml';
let manifest = fs.readFileSync(manifestPath, 'utf8');

if (!manifest.includes('com.google.android.gms.ads.APPLICATION_ID')) {
  const metaTag = `        <meta-data\n            android:name="com.google.android.gms.ads.APPLICATION_ID"\n            android:value="${cfg.admobAppId}" />\n    </application>`;
  manifest = manifest.replace('</application>', metaTag);
}
if (!manifest.includes('android:screenOrientation=')) {
  manifest = manifest.replace('<activity', '<activity\n            android:screenOrientation="portrait"');
}
if (!manifest.includes('android:hardwareAccelerated=')) {
  manifest = manifest.replace('<application', '<application\n        android:hardwareAccelerated="true"');
}
fs.writeFileSync(manifestPath, manifest);

// 2. Patch versionCode & versionName
const appGradlePath = 'android/app/build.gradle';
let appGradle = fs.readFileSync(appGradlePath, 'utf8');
appGradle = appGradle.replace(/versionCode\s+\d+/, `versionCode ${cfg.versionCode || 1}`);
appGradle = appGradle.replace(/versionName\s+"[^"]+"/, `versionName "${cfg.versionName || '1.0.0'}"`);
fs.writeFileSync(appGradlePath, appGradle);

// 3. Target SDK 35 (Google Play requirement)
const varsPath = 'android/variables.gradle';
if (fs.existsSync(varsPath)) {
  let vars = fs.readFileSync(varsPath, 'utf8');
  vars = vars.replace(/compileSdkVersion\s*=\s*\d+/, 'compileSdkVersion = 35');
  vars = vars.replace(/targetSdkVersion\s*=\s*\d+/, 'targetSdkVersion = 35');
  fs.writeFileSync(varsPath, vars);
}

const propsPath = 'android/gradle.properties';
if (fs.existsSync(propsPath)) {
  let props = fs.readFileSync(propsPath, 'utf8');
  if (!props.includes('suppressUnsupportedCompileSdk')) {
    props += '\nandroid.suppressUnsupportedCompileSdk=35\n';
    fs.writeFileSync(propsPath, props);
  }
}

// 4. Replace default Capacitor Android icons with custom Neon Overdrive 3D icons!
const resDir = 'android/app/src/main/res';
const densities = ['mdpi', 'hdpi', 'xhdpi', 'xxhdpi', 'xxxhdpi'];
for (const d of densities) {
  const srcIcon = path.join('assets', 'icons', `ic_launcher_${d}.png`);
  const mipDir = path.join(resDir, `mipmap-${d}`);
  if (fs.existsSync(srcIcon) && fs.existsSync(mipDir)) {
    fs.copyFileSync(srcIcon, path.join(mipDir, 'ic_launcher.png'));
    fs.copyFileSync(srcIcon, path.join(mipDir, 'ic_launcher_round.png'));
    fs.copyFileSync(srcIcon, path.join(mipDir, 'ic_launcher_foreground.png'));
  }
}
// Remove adaptive xml override if foreground/background clash, or keep clean icon
const anydpiDir = path.join(resDir, 'mipmap-anydpi-v26');
if (fs.existsSync(anydpiDir)) {
  fs.rmSync(anydpiDir, { recursive: true, force: true });
}
console.log('Patched Android manifest, SDK 35, and installed custom 3D app icons!');
