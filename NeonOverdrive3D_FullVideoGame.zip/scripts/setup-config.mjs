import fs from 'fs';

const cfg = JSON.parse(fs.readFileSync('admob-config.json', 'utf8'));

const capCfg = {
  appId: cfg.appId,
  appName: cfg.appName,
  webDir: 'www',
  android: {
    backgroundColor: '#04050d'
  }
};
fs.writeFileSync('capacitor.config.json', JSON.stringify(capCfg, null, 2));

const jsContent = `window.ADMOB_CONFIG = ${JSON.stringify({
  isTesting: cfg.isTesting,
  bannerAdId: cfg.bannerAdId,
  interstitialAdId: cfg.interstitialAdId,
  rewardedAdId: cfg.rewardedAdId
}, null, 2)};\n`;

fs.writeFileSync('www/admob-ids.js', jsContent);
console.log('Synced admob-config.json -> capacitor.config.json & www/admob-ids.js');
